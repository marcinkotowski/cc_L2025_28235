namespace Cdv.Functions;

public class MyAssembly
{
    
}